#!/bin/sh
cat /mnt/hosts.append/hosts >> /etc/hosts
sleep 3600 
