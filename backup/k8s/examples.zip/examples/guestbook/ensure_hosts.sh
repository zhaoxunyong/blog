#!/bin/sh
cat /mnt/hosts.append/hosts >> /etc/hosts
