#!/bin/bash

cd ..
rm -fr app-build-full.tgz
tar czf app-build-full.tgz scripts/ email-templates/ /etc/ssl/zerofinance.hk/ /usr/local/etc/nginx/nginx.conf /works/xwallet.png

rm -fr app-build.tgz
tar czf app-build.tgz --exclude=scripts/jiagu/ scripts/ email-templates/ /etc/ssl/zerofinance.hk/ /usr/local/etc/nginx/nginx.conf /works/xwallet.png
