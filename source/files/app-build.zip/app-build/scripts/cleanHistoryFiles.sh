#!/bin/bash

days=30
#Cleaning the files before days of the works directory
find /works/hkcash-* -type f -mtime +${days} -exec rm -rf {} \;
#cleaning the files before days of the app_host directory
find /opt/app-host/shared/public/uploads/pkg -type f -mtime +${days} -exec rm -rf {} \;
echo "Cleaning files is done!"
