#!/bin/bash

days=7
#Cleaning the files before 7 days of the works directory
find /works/hkcash-* -type f -mtime +${days} -exec rm -rf {} \;
#cleaning the files before 7 days of the app_host directory
find /opt/app-host/shared/public/uploads/pkg -type f -mtime +${days} -exec rm -rf {} \;
echo "Cleaning files is done!"
