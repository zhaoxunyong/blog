#!/bin/bash

source /Users/test/.bash_profile

#BUILD_TYPE=$1
#PLATFORM=$2
#WORKSPACE=$3
#ENV=$4
#GIT_BRANCH=$5

#The signer tool which for singed a apk ile
APKSIGNER=/Developer/Android/sdk/build-tools/29.0.0/apksigner
#The qrcode tool which for generate a qrcode from url
QRENCODE=/usr/local/bin/qrencode

#The script home
SCRIPTS_HOME=/Users/test/.jenkins/scripts
#The base path for geneated's files
SAVE_BASE_PATH=/works
#The temporary variable between this script and email jelly file
TMP_PROPERTIES_FILE=/tmp/${JOB_NAME}-${ENV}-${BUILD_NUMBER}.properties
#App name
APP_NAME=xwallet

#The base release name of git
RELEASE_NAME=${GIT_BRANCH//origin\//}
#The app host url
APP_HOST_URL=${JENKINS_URL//ci\//}
#The download base url
APP_BASE_URL=${JENKINS_URL}appDownloads
#the external base url, only for reinforcing apk
EXTERNAL_BASE_URL=http://218.17.1.146:45682/ci/appDownloads
#The substring path
SUB_PATH=${JOB_NAME}/${ENV}/${RELEASE_NAME}
#The final app url
APP_URL=${APP_BASE_URL}/${SUB_PATH}/${BUILD_NUMBER}
#The final external url, only for reinforcing apk
EXTERNAL_URL=${EXTERNAL_BASE_URL}/${SUB_PATH}/${BUILD_NUMBER}
#The path for geneated's files, only for copying geneated files to antoher directory
APP_SAVE_PATH=${SAVE_BASE_PATH}/${SUB_PATH}/${BUILD_NUMBER}
#ios altool path, only for uploading ipa to app store
ALTOOLPATH=/Applications/Xcode.app/Contents/Applications/Application\ Loader.app/Contents/Frameworks/ITunesSoftwareService.framework/Versions/A/Support/altool
#Developement plist
DEV_PLIST=${SCRIPTS_HOME}/developement.plist
#Release plist
RELEASE_PLIST=${SCRIPTS_HOME}/release.plist
#the plist file which for itms-services
PLIST_TEMPLATE=${SCRIPTS_HOME}/plist.template
#verification for building
signingConfigs=${SCRIPTS_HOME}/signingConfigs.properties
appId=$(cat ${signingConfigs} |grep appId|awk -F '=' '{print $2}')
appPassword=$(cat ${signingConfigs} |grep appPassword|awk -F '=' '{print $2}')
apphostToken=$(cat ${signingConfigs} |grep apphostToken|awk -F '=' '{print $2}')
secretId=$(cat ${signingConfigs} |grep secretId|awk -F '=' '{print $2}')
secretKey=$(cat ${signingConfigs} |grep secretKey|awk -F '=' '{print $2}')
storePassword=$(cat ${signingConfigs} |grep storePassword|awk -F '=' '{print $2}')
keyPassword=$(cat ${signingConfigs} |grep keyPassword|awk -F '=' '{print $2}')
storeFile=$(cat ${signingConfigs} |grep storeFile|awk -F '=' '{print $2}')
#Make sure APP_SAVE_PATH existed
mkdir -p $APP_SAVE_PATH
#passing variable to email jelly file
echo "appUrl=$APP_URL" >> $TMP_PROPERTIES_FILE
echo "appHostUrl=$APP_HOST_URL" >> $TMP_PROPERTIES_FILE

#Get the id of the APP_HOST platform
function getPlatId() {
  if [[ "$ENV" == "test" ]]; then
    if [[ "$platformParam" == "android" ]]; then
        echo 1
    else
        echo 5
    fi
  elif [[ "$ENV" == "testtemp" ]]; then
    if [[ "$platformParam" == "android" ]]; then
        echo 2
    else
        echo 6
    fi
  elif [[ "$ENV" == "uat" ]]; then
    if [[ "$platformParam" == "android" ]]; then
        echo 3
    else
        echo 7
    fi
  elif [[ "$ENV" == "prod" ]]; then
    if [[ "$platformParam" == "android" ]]; then
        echo 4
    else
        echo 8
    fi
  fi
}

#Uploading app to APP_HOST which is a APP publish website
function uploadApp() {
  platformParam=$1
  filePath=$2
  appJenkinsUrl=$3
  iosIpaUrl=$4
  echo "Uploading app for $platformParam..."
  
  echo "appJenkinsUrl=$appJenkinsUrl"
  #curl -s -X GET -G 'https://api.ooopn.com/qr/api.php' \
  #  --data-urlencode text="$appJenkinsUrl" \
  #  -d size=100px > $APP_SAVE_PATH/${platformParam}_qrcode.png
  #downloadUrl=`node -e "console.info(encodeURIComponent('$appJenkinsUrl'))"`
  ${QRENCODE} -o $APP_SAVE_PATH/${platformParam}_qrcode.png -s 8 -m 1 "$appJenkinsUrl"
  #qrcodeGetUrl="https://api.ooopn.com/qr/api.php?text=$downloadUrl&size=150px"
  qrcodeGetUrl="${APP_URL}/${platformParam}_qrcode.png"
  echo "${platformParam}_downloadUrl=$qrcodeGetUrl" >> $TMP_PROPERTIES_FILE
  echo "$appJenkinsUrl" | grep "itms-services" > /dev/null
  if [[ $? == 0 ]]; then
    directUrl=$iosIpaUrl
  else
    directUrl=$appJenkinsUrl
  fi
  echo "directUrl=$directUrl"
  echo "${platformParam}_directUrl=$directUrl" >> $TMP_PROPERTIES_FILE
  #echo "${platformParam}_directUrl=$appJenkinsUrl" >> $TMP_PROPERTIES_FILE
  #echo "appUrl=$APP_URL" >> $TMP_PROPERTIES_FILE
  
  file_nick_name=${APP_NAME}-${platformParam}-${RELEASE_NAME}-${BUILD_NUMBER}
  features="upload for ${file_nick_name}"
  
  echo "Uploading app to APP_HOST for $platformParam..."
  plat_id=`getPlatId`
  echo "platId=$plat_id" >> $TMP_PROPERTIES_FILE
  curl -s --form plat_id=$plat_id \
    --form file_nick_name=$file_nick_name \
    --form token=$apphostToken \
    --form features="$features" \
    --form file=@$filePath https://appbuild.zerofinance.hk/api/pkgs > /dev/null
  if [[ $? == 0 ]]; then
    echo "Uploading app to APP_HOST for $platformParam successfully..."
  else
    echo "Uploading app to APP_HOST for $platformParam is failed..."
    exit -1
  fi
  
  echo "Uploading app for $platformParam successfully..."
  return 0
}

#Building android app
function buildAndroid() {
  #for android
  BUILD_PLATFORM="android"
  rm -fr $APP_SAVE_PATH/Android.bundle.zip $APP_SAVE_PATH/*.apk $APP_SAVE_PATH/android_qrcode.png
  cd ${WORKSPACE}
  sed -i "" "s;^ *export const ENV *= *'.*';export const ENV = '${ENV}';g" ${WORKSPACE}/component/Common/Environment.js
  echo "Building android: npm install"
  npm install > /dev/null
  echo "Building android: npm run build-android"
  npm run build-android > /dev/null
  cd android
  rm -fr $output/*.apk
  if [[ "$ONLY_HOTUPDATE" == "N" ]]; then
    echo "Building android: ./gradlew clean assemble$BUILD_TYPE"
    if [[ "$BUILD_TYPE" == "Release" ]]; then
      output=app/build/outputs/apk/release/
      ./gradlew clean assembleRelease --stacktrace -PIS_JENKINS=true -PBUILD_TYPE=${BUILD_TYPE} > /dev/null
    else
      output=app/build/outputs/apk/debug/
      ./gradlew clean assembleDebug --stacktrace -PIS_JENKINS=true -PBUILD_TYPE=${BUILD_TYPE} > /dev/null
    fi
  fi
  
  if [[ $? == 0 ]]; then
    # hot update package
    currPwd=`pwd`
    cd ${WORKSPACE}/android/app/src/main/assets
    zip -rq ${APP_SAVE_PATH}/Android.bundle.zip *
    cd $currPwd
    apkFile=`ls $output|grep apk`
    if [[ $? == 0 && -f $output/$apkFile ]]; then
      filePath=$output/$apkFile
      singedApkPath=$APP_SAVE_PATH/${apkFile}

      if [[ "$ENV" == "prod" ]]; then
        externalApkFile=${apkFile//.apk/}_unreinforce.apk
        unsingedApkFile=${apkFile//.apk/}_unsinged.apk
        cp -a $filePath $APP_SAVE_PATH/${externalApkFile}
        
        apkUrl=${EXTERNAL_URL}/${externalApkFile}
        apkPath=${filePath}
        downloadApkPath=$APP_SAVE_PATH/${unsingedApkFile}
        echo "Reinforcing the apk..."
        cd ${WORKSPACE}/android
        ./gradlew _leguJiaGu -PapkUrl=${apkUrl} -PapkPath=${apkPath} -PdownloadApkPath=${downloadApkPath} \
          -PsecretId=${secretId} -PsecretKey=${secretKey}
        
        if [[ ! -f "$downloadApkPath" ]]; then
          echo "Reinforcing the apk failed..."
          exit -1
        else
          echo "Reinforcing the apk successfully..."
        fi
        echo "Signing the apk..."
        ${APKSIGNER} sign \
          --ks ${storeFile} \
          --ks-pass pass:"${storePassword}" --key-pass pass:"${keyPassword}" \
          --out $singedApkPath ${downloadApkPath}

        if [[ $? != 0 ]]; then
          echo "Signing the apk failed..."
          exit -1
        else
          echo "Signing the apk successfully..."
        fi
      else
        cp -a $filePath $singedApkPath
      fi

      appJenkinsUrl="${APP_URL}/$apkFile"
      uploadApp $BUILD_PLATFORM $filePath $appJenkinsUrl
      if [[ $? != 0 ]]; then
	      echo "Building android is successful, but upload failed, maybe caused by establishing network, it exited, please try again."
        exit -1
      fi
    fi
  else
    echo "Building android is failed. it exited."
    exit -1
  fi
}

#Building ios app
function buildIos() {
  # for ios
  BUILD_PLATFORM="ios"
  rm -fr $APP_SAVE_PATH/IOS.bundle.zip $APP_SAVE_PATH/*.ipa $APP_SAVE_PATH/*.plist $APP_SAVE_PATH/ios_qrcode.png
  cd ${WORKSPACE}
  sed -i "" "s;^ *export const ENV *= *'.*';export const ENV = '${ENV}';g" ${WORKSPACE}/component/Common/Environment.js
  echo "Building ios: npm install"
  npm install > /dev/null
  echo "Building ios: npm run build-ios"
  npm run build-ios > /dev/null
  cd ios

  output=build/outputs/
  rm -fr $output/*.ipa $output/*.xcarchive
  
  if [[ "$ONLY_HOTUPDATE" == "N" ]]; then
    echo "Building ios: pod install"
    /usr/local/bin/pod install
    echo "Building ios: xcodebuild clean"
    xcodebuild \
      -workspace "${APP_NAME}.xcworkspace" \
      -scheme "${APP_NAME}"  \
      -configuration "${BUILD_TYPE}" \
      clean > /dev/null

    echo "Building ios: xcodebuild archive"
    xcodebuild archive -workspace "${APP_NAME}.xcworkspace" \
      -scheme ${APP_NAME} \
      -configuration "${BUILD_TYPE}" \
      -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" > /dev/null

    echo "Building ios: xcodebuild export archive to ipa"

    if [[ "$ENV" == "prod" ]]; then
      xcodebuild -exportArchive -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" \
        -exportPath "${output}/${APP_NAME}-${BUILD_TYPE}.ipa" \
        -exportOptionsPlist $RELEASE_PLIST  > /dev/null
    
      if [[ "$UPLOAD_APPSTORE" == "Y" ]]; then
        IPAPATH=${output}/${APP_NAME}-${BUILD_TYPE}.ipa/${APP_NAME}.ipa
        echo "Uploading file to app store, it may make a few minutes, please wait..."
        "${ALTOOLPATH}" --upload-app -f "${IPAPATH}" -u "${appId}" -p "${appPassword}" --output-format xml | grep "No errors uploading" > /dev/null
        if [[ $? != 0 ]]; then
          echo "Building ios successfully, but uploading to app store failed!"
          exit -1
        else
          echo "Uploading file to app store successfully!"
        fi
      fi
    else
      xcodebuild -exportArchive -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" \
        -exportPath "${output}/${APP_NAME}-${BUILD_TYPE}.ipa" \
        -exportOptionsPlist $DEV_PLIST  > /dev/null
    fi
  fi
  if [[ $? == 0 ]]; then
    currPwd=`pwd`
    cd ${WORKSPACE}/ios/bundle
    zip -rq ${APP_SAVE_PATH}/IOS.bundle.zip *
    cd $currPwd
    ipaFile=`ls $output|grep ipa`
    if [[ $? == 0 && -d $output/$ipaFile ]]; then
      filePath=$output/$ipaFile/${APP_NAME}.ipa
      cp -a $filePath $APP_SAVE_PATH/
      iosIpaUrl=${APP_URL}/${APP_NAME}.ipa
      pngUrl=${APP_BASE_URL}/xwallet.png
      md5Size=`ls -l $filePath | awk '{print $5}'`
      cat $PLIST_TEMPLATE | sed "s;#{downloadFile};${iosIpaUrl};g" | sed "s;#{md5Size};${md5Size};g"| sed "s;#{pngFile};${pngUrl};g" | sed "s;#{releaseName};$RELEASE_NAME;g" > $APP_SAVE_PATH/${APP_NAME}.plist
      appJenkinsUrl="itms-services://?action=download-manifest&url=${APP_URL}/${APP_NAME}.plist"
      uploadApp $BUILD_PLATFORM $filePath $appJenkinsUrl $iosIpaUrl
      if [[ $? != 0 ]]; then
        echo "Building ios is successful, but upload failed, maybe caused by establishing network, it exited, please try again."
	      exit -1
      fi
    fi
  else
    echo "Building ios is failed, it exited."
    exit -1
  fi
}

#Starting build
if [[ "$PLATFORM" == "android" ]]; then
  buildAndroid
elif [[ "$PLATFORM" == "ios" ]]; then
  buildIos
elif [[ "$PLATFORM" == "both" ]]; then
  buildAndroid
  buildIos
fi

#Tagging for the prod git release version
if [[ "$ENV" == "prod" ]]; then
  echo "Tagging the release version for prod..."
  releaseBranch=${GIT_BRANCH//origin\//}
  newTag=${releaseBranch}-`date +%Y%m%d%H%M`
  git tag -a $newTag -m "For prod version ${newTag} based on $releaseBranch via jenkins"
  git push origin ${newTag}
fi
