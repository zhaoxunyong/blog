#!/bin/bash

source /Users/test/.bash_profile

BUILD_TYPE=$1
BUILD_PLATFORM=$2
WORKSPACE=$3
ENV=$4
GIT_BRANCH=$5
QRCODE_BASE_URL=$6

RELEASE_NAME=${GIT_BRANCH//origin\//}
APP_BASE_URL=${JENKINS_URL}appDownloads
SAVE_BASE_PATH=/works
SUB_PATH=${JOB_NAME}/${ENV}/${RELEASE_NAME}
APP_URL=${APP_BASE_URL}/${SUB_PATH}
APP_SAVE_PATH=${SAVE_BASE_PATH}/${SUB_PATH}
mkdir -p $APP_SAVE_PATH
APP_NAME=xwallet

ALTOOLPATH=/Applications/Xcode.app/Contents/Applications/Application\ Loader.app/Contents/Frameworks/ITunesSoftwareService.framework/Versions/A/Support/altool
DEV_PLIST=/Users/test/.jenkins/scripts/developement.plist
RELEASE_PLIST=/Users/test/.jenkins/scripts/release.plist
APPID=
APPPASSWORD=

function uploadApp() {
  platform=$1
  filePath=$2
  appJenkinsUrl=$3
  iosIpaUrl=$4
  echo "Uploading app for $platform..."
  
  echo "appJenkinsUrl=$appJenkinsUrl"
  curl -s -X GET -G 'https://api.ooopn.com/qr/api.php' \
    --data-urlencode text="$appJenkinsUrl" \
    -d size=100px > $APP_SAVE_PATH/${platform}_qrcode.png
  #downloadUrl=`node -e "console.info(encodeURIComponent('$appJenkinsUrl'))"`
  #qrcodeGetUrl="https://api.ooopn.com/qr/api.php?text=$downloadUrl&size=150px"
  qrcodeGetUrl="${APP_URL}/${platform}_qrcode.png"
  echo "${platform}_downloadUrl=$qrcodeGetUrl" >> /tmp/${JOB_NAME}-${ENV}-${BUILD_NUMBER}.properties
  echo "$appJenkinsUrl" | grep "itms-services" > /dev/null
  if [[ $? == 0 ]]; then
    directUrl=$iosIpaUrl
  else
    directUrl=$appJenkinsUrl
  fi
  echo "directUrl=$directUrl"
  #echo "${platform}_directUrl=$directUrl" >> /tmp/${JOB_NAME}-${ENV}-${BUILD_NUMBER}.properties
  echo "${platform}_directUrl=$appJenkinsUrl" >> /tmp/${JOB_NAME}-${ENV}-${BUILD_NUMBER}.properties
  echo "appUrl=$APP_URL" >> /tmp/${JOB_NAME}-${ENV}-${BUILD_NUMBER}.properties
  echo "Uploading app for $platform successfully..."
  return 0
}

function buildAndroid() {
  #for android
  PLATFORM="android"
  rm -fr $APP_SAVE_PATH/Android.bundle.zip $APP_SAVE_PATH/*.apk
  cd ${WORKSPACE}
  sed -i "" "s;^ *export const ENV *= *'.*';export const ENV = '${ENV}';g" ${WORKSPACE}/component/Common/Environment.js
  echo "Building android: npm install"
  npm install > /dev/null
  echo "Building android: npm run build-android"
  npm run build-android > /dev/null
  cd android
  rm -fr $output/*.apk
  echo "Building android: ./gradlew clean assemble$BUILD_TYPE"
  if [[ "$BUILD_TYPE" == "Release" ]]; then
    output=app/build/outputs/apk/release/
    ./gradlew clean assembleRelease --stacktrace -PIS_JENKINS=true -PBUILD_TYPE=${BUILD_TYPE} > /dev/null
  else
    output=app/build/outputs/apk/debug/
    ./gradlew clean assembleDebug --stacktrace -PIS_JENKINS=true -PBUILD_TYPE=${BUILD_TYPE} > /dev/null
  fi
  
  if [[ $? == 0 ]]; then
    # hot update package
    currPwd=`pwd`
    cd ${WORKSPACE}/android/app/src/main/assets
    zip -rq ${APP_SAVE_PATH}/Android.bundle.zip *
    cd $currPwd
    apkFile=`ls $output|grep apk`
    if [[ -f $output/$apkFile ]]; then
      filePath=$output/$apkFile
      cp -a $filePath $APP_SAVE_PATH/
      appJenkinsUrl="${APP_URL}/$apkFile"
      uploadApp $PLATFORM $filePath $appJenkinsUrl
      if [[ $? != 0 ]]; then
	echo "Building android is successful, but upload failed, maybe caused by establishing network, it exited, please try again."
        exit -1
      fi
    fi
  else
    echo "Building android is failed. it exited."
    exit -1
  fi
}

function buildIos() {
  # for ios
  PLATFORM="ios"
  rm -fr $APP_SAVE_PATH/IOS.bundle.zip $APP_SAVE_PATH/*.ipa $APP_SAVE_PATH/*.plist
  cd ${WORKSPACE}
  sed -i "" "s;^ *export const ENV *= *'.*';export const ENV = '${ENV}';g" ${WORKSPACE}/component/Common/Environment.js
  echo "Building ios: npm install"
  npm install > /dev/null
  echo "Building ios: npm run build-ios"
  npm run build-ios > /dev/null
  cd ios

  echo "Building ios: pod install"
  /usr/local/bin/pod install

  output=build/outputs/
  rm -fr $output/*.ipa $output/*.xcarchive

  echo "Building ios: xcodebuild clean"
  xcodebuild \
      -workspace "${APP_NAME}.xcworkspace" \
      -scheme "${APP_NAME}"  \
      -configuration "${BUILD_TYPE}" \
      clean > /dev/null

  echo "Building ios: xcodebuild archive"
  xcodebuild archive -workspace "${APP_NAME}.xcworkspace" \
      -scheme ${APP_NAME} \
      -configuration "${BUILD_TYPE}" \
      -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" > /dev/null

  echo "Building ios: xcodebuild export archive to ipa"

  if [[ "$ENV" == "prod" ]]; then
    xcodebuild -exportArchive -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" \
      -exportPath "${output}/${APP_NAME}-${BUILD_TYPE}.ipa" \
      -exportOptionsPlist $RELEASE_PLIST  > /dev/null
    
    if [[ "$UPLOAD_APPSTORE" == "Y" ]]; then
      IPAPATH=${output}/${APP_NAME}-${BUILD_TYPE}.ipa/${APP_NAME}.ipa
      echo "Uploading file to app store, it may make a few minutes, please wait..."
      "${ALTOOLPATH}" --upload-app -f "${IPAPATH}" -u "${APPID}" -p "${APPPASSWORD}" --output-format xml | grep "No errors uploading" > /dev/null
      if [[ $? != 0 ]]; then
        echo "Building ios successfully, but uploading to app store failed!"
        exit -1
      else
        echo "Uploading file to app store successfully!"
      fi
    fi
  else
    xcodebuild -exportArchive -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" \
      -exportPath "${output}/${APP_NAME}-${BUILD_TYPE}.ipa" \
      -exportOptionsPlist $DEV_PLIST  > /dev/null
  fi

  if [[ $? == 0 ]]; then
    currPwd=`pwd`
    cd ${WORKSPACE}/ios/bundle
    zip -rq ${APP_SAVE_PATH}/IOS.bundle.zip *
    cd $currPwd
    ipaFile=`ls $output|grep ipa`
    if [[ -d $output/$ipaFile ]]; then
      filePath=$output/$ipaFile/${APP_NAME}.ipa
      cp -a $filePath $APP_SAVE_PATH/
      iosIpaUrl=${APP_URL}/${APP_NAME}.ipa
      pngUrl=${APP_BASE_URL}/xwallet.png
      md5Size=`ls -l $filePath | awk '{print $5}'`
      cat /Users/test/.jenkins/scripts/plist.template | sed "s;#{downloadFile};${iosIpaUrl};g" | sed "s;#{md5Size};${md5Size};g"| sed "s;#{pngFile};${pngUrl};g" | sed "s;#{releaseName};$RELEASE_NAME;g" > $APP_SAVE_PATH/${APP_NAME}.plist
      appJenkinsUrl="itms-services://?action=download-manifest&url=${APP_URL}/${APP_NAME}.plist"
      uploadApp $PLATFORM $filePath $appJenkinsUrl $iosIpaUrl
      if [[ $? != 0 ]]; then
        echo "Building ios is successful, but upload failed, maybe caused by establishing network, it exited, please try again."
	exit -1
      fi
    fi
  else
    echo "Building ios is failed, it exited."
    exit -1
  fi
}

if [[ "$BUILD_PLATFORM" == "android" ]]; then
  buildAndroid
elif [[ "$BUILD_PLATFORM" == "ios" ]]; then
  buildIos
elif [[ "$BUILD_PLATFORM" == "both" ]]; then
  buildAndroid
  buildIos
fi

if [[ "$ENV" == "prod" ]]; then
  echo "Tagging the release version for prod..."
  releaseBranch=${GIT_BRANCH//origin\//}
  newTag=${releaseBranch}-`date +%Y%m%d%H%M`
  git tag -a $newTag -m "For prod version ${newTag} based on $releaseBranch via jenkins"
  git push origin ${newTag}
fi
