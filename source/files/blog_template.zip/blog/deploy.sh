#!/bin/sh
hexo clean
hexo g
hexo d
