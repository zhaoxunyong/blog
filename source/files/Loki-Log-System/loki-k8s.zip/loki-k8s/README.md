loki:
bucket: loki-monitor-files
loki-monitor-test.zerofinance.net

bucket: loki-syslog-files
loki-syslog-test.zerofinance.net

bucket: loki-report-files
loki-report-test.zerofinance.net

grafana:
logs-test.zerofinance.net

alertmanager:
am-test.zerofinance.net

kafka(LoadBalancer):
kafka-broker-test.zerofinance.net

kafka-ui:
kafka-ui-test.zerofinance.net