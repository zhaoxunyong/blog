#!/bin/bash

source /Users/test/.bash_profile

BUILD_TYPE=$1
PLATFORM=$2
APP_NAME=xwallet
serverUrl=https://www.xx.com
currentAppIdFile=${JENKINS_HOME}/scripts/currentAppId_${APP_NAME}_${PLATFORM}
token=`curl -s -X POST "${serverUrl}/api/user/login" -H "accept: application/json" -H "Authorization: cabf435869e9bd4f24f8cbde9162531f" -H "content-type: application/json" -d "{ \"username\": \"xxx\", \"password\": \"yyy\"}" | python -mjson.tool | grep token | awk -F'[:"]' '{print $5}'`
teamId=`curl -s -X GET ${serverUrl}/api/user/teams -H "accept: application/json" -H "Authorization: Bearer ${token}" | python -mjson.tool | grep _id | awk -F'[:"]' '{print $5}' | head -1`
    

function deleteMaxApp() {
  appId=`cat ${currentAppIdFile}`
  echo "appId======${appId}"
  if [[ "$appId" != "" ]]; then
    currentVersions=(`curl -s -X GET "${serverUrl}/api/apps/${teamId}/${appId}/versions?page=0&size=9999" \
      -H "accept: application/json" \
      -H "Authorization: Bearer ${token}" \
      | python -mjson.tool | egrep "_id|versionCode" |tail -n 2 | awk -F'[:"]' '{print $5}'`)
    
    versionId=${currentVersions[0]}
    versionCode=${currentVersions[1]}

    curl -X DELETE "${serverUrl}/api/apps/${teamId}/${appId}/versions/${versionId}" \
      -H "accept: application/json" \
      -H "Authorization: Bearer ${token}"
  fi
}

function uploadApp() {
  filePath=$1
  appId=`curl -s -X POST "${serverUrl}/api/apps/${teamId}/upload" \
        -H "accept: application/json" \
        -H "Authorization: Bearer ${token}" \
        -H "content-type: multipart/form-data" \
        -F "file=@$filePath;type=application/vnd.${PLATFORM}.package-archive" | python -mjson.tool | grep appId | awk -F'[:"]' '{print $5}' | head -1`

  if [[ "$appId" == "" ]]; then
    echo "Uploading apk failure."
    return -1
  else
    echo "$appId" > ${currentAppIdFile}
    return 0
  fi
}

if [[ "$PLATFORM" == "android" ]]; then
  #for android
  echo "Starting npm install..."
  npm install > /dev/null
  echo "Starting npm build..."
  npm run build-android > /dev/null
  cd android
  # currentAppVersionName=`cat gradle.properties |grep appVersionCode|awk -F '=' '{print $2}'`
  # currentAppVersionName=$(( $currentAppVersionName + 1 ))
  # sed -i "" "s;appVersionCode=.*;appVersionCode=${currentAppVersionName};" gradle.properties
  rm -fr $output/*.apk
  echo "Starting build..."
  if [[ "$BUILD_TYPE" == "Release" ]]; then
    output=app/build/outputs/apk/release/
    ./gradlew clean assembleRelease -PIS_JENKINS=true -PBUILD_TYPE=${BUILD_TYPE} > /dev/null
  else
    output=app/build/outputs/apk/debug/
    ./gradlew clean assembleDebug -PIS_JENKINS=true -PBUILD_TYPE=${BUILD_TYPE} > /dev/null
  fi
  
  if [[ $? == 0 ]]; then
    apkFile=`ls $output|grep apk`
    if [[ -f $output/$apkFile ]]; then
      filePath=$output/$apkFile
      uploadApp $filePath
      if [[ $? != 0 ]]; then
        # exception
        echo "Upload failure, deleting the max version..."
        deleteMaxApp
        uploadApp $filePath
      fi
    fi
  fi

elif [[ "$PLATFORM" == "ios" ]]; then
  # for ios
  echo "Starting npm install..."
  npm install > /dev/null
  echo "Starting npm build..."
  npm run build-ios > /dev/null
  cd ios

  output=build/outputs/
  rm -fr $output/*.ipa $output/*.xcarchive

  echo "Starting build..."
  xcodebuild \
      -workspace "${APP_NAME}.xcworkspace" \
      -scheme "${APP_NAME}"  \
      -configuration "${BUILD_TYPE}" \
      clean > /dev/null

  xcodebuild archive -workspace "${APP_NAME}.xcworkspace" \
      -scheme ${APP_NAME} \
      -configuration "${BUILD_TYPE}" \
      -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" > /dev/null

  cat << EOF > ./build.plist
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>method</key>
  <string>development</string>
  <key>compileBitcode</key>
  <false/>
</dict>
</plist>
EOF

  xcodebuild -exportArchive -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" \
    -exportPath "${output}/${APP_NAME}-${BUILD_TYPE}.ipa" \
    -exportOptionsPlist build.plist  > /dev/null

  if [[ $? == 0 ]]; then
    ipaFile=`ls $output|grep ipa`
    if [[ -d $output/$ipaFile ]]; then
      filePath=$output/$ipaFile/${APP_NAME}.ipa
      uploadApp $filePath
      if [[ $? != 0 ]]; then
        # exception
        echo "Upload failure, deleting the max version..."
        deleteMaxApp
        uploadApp $filePath
      fi
    fi
  fi
fi
