#!/bin/bash

source /Users/test/.bash_profile

BUILD_TYPE=$1
BUILD_PLATFORM=$2
WORKSPACE=$3
ENV=$4
APP_NAME=xwallet
serverUrl=https://www.xxx.com
token=`curl -s -X POST "${serverUrl}/api/user/login" -H "accept: application/json" -H "Authorization: cabf435869e9bd4f24f8cbde9162531f" -H "content-type: application/json" -d "{ \"username\": \"zhaoxunyong\", \"password\": \"xxx\"}" | python -mjson.tool | grep token | awk -F'[:"]' '{print $5}'`

if [[ "$token" == "" ]]; then
    echo "Login failure."
    return -1
fi

teamId=`curl -s -X GET ${serverUrl}/api/user/teams -H "accept: application/json" -H "Authorization: Bearer ${token}" | python -mjson.tool | grep _id | awk -F'[:"]' '{print $5}' | head -1`
    

function deleteMaxApp() {
  platform=$1
  currentAppIdFile=${JENKINS_HOME}/scripts/currentAppId_${APP_NAME}_${platform}_uat
  appId=`cat ${currentAppIdFile}`
  echo "appId======${appId}"
  if [[ "$appId" != "" ]]; then
    currentVersions=(`curl -s -X GET "${serverUrl}/api/apps/${teamId}/${appId}/versions?page=0&size=9999" \
      -H "accept: application/json" \
      -H "Authorization: Bearer ${token}" \
      | python -mjson.tool | egrep "_id|versionCode" |tail -n 2 | awk -F'[:"]' '{print $5}'`)
    
    versionId=${currentVersions[0]}
    versionCode=${currentVersions[1]}

    curl -X DELETE "${serverUrl}/api/apps/${teamId}/${appId}/versions/${versionId}" \
      -H "accept: application/json" \
      -H "Authorization: Bearer ${token}"
  fi
}

function uploadApp() {
  platform=$1
  filePath=$2
  currentAppIdFile=${JENKINS_HOME}/scripts/currentAppId_${APP_NAME}_${platform}_uat
  appId=`curl -s -X POST "${serverUrl}/api/apps/${teamId}/upload" \
        -H "accept: application/json" \
        -H "Authorization: Bearer ${token}" \
        -H "content-type: multipart/form-data" \
        -F "file=@$filePath;type=application/vnd.${platform}.package-archive" | python -mjson.tool | grep appId | awk -F'[:"]' '{print $5}' | head -1`

  if [[ "$appId" == "" ]]; then
    return -1
  else
    echo "$appId" > ${currentAppIdFile}
    return 0
  fi
}

function buildAndroid() {
  #for android
  PLATFORM="android"
  cd ${WORKSPACE}
  sed -i "" "s;^ *export const ENV *= *'.*';export const ENV = '${ENV}';g" ${WORKSPACE}/component/Common/Environment.js
  rm -fr ${WORKSPACE}/android/app/src/main/Android.bundle.zip
  echo "Starting android: npm install"
  npm install > /dev/null
  echo "Starting android: npm run build-android"
  npm run build-android > /dev/null
  cd android
  # currentAppVersionName=`cat gradle.properties |grep appVersionCode|awk -F '=' '{print $2}'`
  # currentAppVersionName=$(( $currentAppVersionName + 1 ))
  # sed -i "" "s;appVersionCode=.*;appVersionCode=${currentAppVersionName};" gradle.properties
  rm -fr $output/*.apk
  echo "Starting android: ./gradlew clean assemble$BUILD_TYPE"
  if [[ "$BUILD_TYPE" == "Release" ]]; then
    output=app/build/outputs/apk/release/
    ./gradlew clean assembleRelease --stacktrace -PIS_JENKINS=true -PBUILD_TYPE=${BUILD_TYPE} > /dev/null
  else
    output=app/build/outputs/apk/debug/
    ./gradlew clean assembleDebug --stacktrace -PIS_JENKINS=true -PBUILD_TYPE=${BUILD_TYPE} > /dev/null
  fi
  
  if [[ $? == 0 ]]; then
    # hot update package
    currPwd=`pwd`
    cd ${WORKSPACE}/android/app/src/main/assets
    zip -rq ../Android.bundle.zip *
    cd $currPwd
    apkFile=`ls $output|grep apk`
    if [[ -f $output/$apkFile ]]; then
      filePath=$output/$apkFile
      uploadApp $PLATFORM $filePath
      if [[ $? != 0 ]]; then
        # exception
        echo "Deleting the maximum version..."
        deleteMaxApp $PLATFORM
        uploadApp $PLATFORM $filePath
      fi
    fi
  else
    echo "Android build failure. exit."
    exit -1
  fi
}

function buildIos() {
  # for ios
  PLATFORM="ios"
  cd ${WORKSPACE}
  sed -i "" "s;^ *export const ENV *= *'.*';export const ENV = '${ENV}';g" ${WORKSPACE}/component/Common/Environment.js
  rm -fr ${WORKSPACE}/ios/IOS.bundle.zip
  echo "Starting ios: npm install"
  npm install > /dev/null
  echo "Starting ios: npm run build-ios"
  npm run build-ios > /dev/null
  cd ios

  echo "Starting ios: pod install"
  /usr/local/bin/pod install

  output=build/outputs/
  rm -fr $output/*.ipa $output/*.xcarchive

  echo "Starting ios: xcodebuild clean"
  xcodebuild \
      -workspace "${APP_NAME}.xcworkspace" \
      -scheme "${APP_NAME}"  \
      -configuration "${BUILD_TYPE}" \
      clean > /dev/null

  echo "Starting ios: xcodebuild archive"
  xcodebuild archive -workspace "${APP_NAME}.xcworkspace" \
      -scheme ${APP_NAME} \
      -configuration "${BUILD_TYPE}" \
      -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" > /dev/null

  cat << EOF > ./build.plist
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>method</key>
  <string>development</string>
  <key>compileBitcode</key>
  <false/>
</dict>
</plist>
EOF

  echo "Starting ios: xcodebuild export exportArchive to ipa"
  xcodebuild -exportArchive -archivePath "${output}/${APP_NAME}-${BUILD_TYPE}.xcarchive" \
    -exportPath "${output}/${APP_NAME}-${BUILD_TYPE}.ipa" \
    -exportOptionsPlist build.plist  > /dev/null

  if [[ $? == 0 ]]; then
    currPwd=`pwd`
    cd ${WORKSPACE}/ios/bundle
    zip -rq ../IOS.bundle.zip *
    cd $currPwd
    ipaFile=`ls $output|grep ipa`
    if [[ -d $output/$ipaFile ]]; then
      filePath=$output/$ipaFile/${APP_NAME}.ipa
      uploadApp $PLATFORM $filePath
      if [[ $? != 0 ]]; then
        # exception
        echo "Deleting the maximum version..."
        deleteMaxApp $PLATFORM
        uploadApp $PLATFORM $filePath
      fi
    fi
  else
    echo "IOS build failure. exit."
    exit -1
  fi
}

if [[ "$BUILD_PLATFORM" == "android" ]]; then
  buildAndroid
elif [[ "$BUILD_PLATFORM" == "ios" ]]; then
  buildIos
elif [[ "$BUILD_PLATFORM" == "both" ]]; then
  buildAndroid
  buildIos
fi
